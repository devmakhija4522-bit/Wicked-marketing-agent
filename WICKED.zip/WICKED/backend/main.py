from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from backend.models import PipelineRequest
from backend.agents.trend_scout import run_trend_scout
from backend.agents.insight_analyst import run_insight_analyst
from backend.agents.content_strategist import run_content_strategist
from backend.agents.script_writer import run_script_writer
from backend.agents.brand_guardian import run_brand_guardian

app = FastAPI(title="WICKED — Marketing Agent System")

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_methods=["*"],
    allow_headers=["*"],
)

@app.get("/")
def root():
    return {"status": "WICKED is running 🔥"}

@app.post("/api/discover-trends")
def discover_trends():
    trends = run_trend_scout()
    return {"trends": trends, "count": len(trends)}

@app.post("/api/analyze-trends")
def analyze_trends():
    trends = run_trend_scout()
    insights = run_insight_analyst(trends)
    return {"insights": insights}

@app.post("/api/generate-concepts")
def generate_concepts():
    trends = run_trend_scout()
    insights = run_insight_analyst(trends)
    concepts = run_content_strategist(insights)
    return {"concepts": concepts}

@app.post("/api/write-script")
def write_script(request: PipelineRequest):
    trends = run_trend_scout()
    insights = run_insight_analyst(trends)
    concepts = run_content_strategist(insights)
    if not concepts:
        return {"error": "No concepts generated"}
    top_concept = concepts[0]
    script = run_script_writer(top_concept, request.language, request.style_samples)
    return {"script": script}

@app.post("/api/full-pipeline")
def full_pipeline(request: PipelineRequest):
    # Step 1: Trends
    trends = run_trend_scout()

    # Step 2: Insights
    insights = run_insight_analyst(trends)

    # Step 3: Concepts
    concepts = run_content_strategist(insights)
    if not concepts:
        return {"error": "No concepts generated"}

    # Step 4: Script
    top_concept = concepts[0]
    script = run_script_writer(top_concept, request.language, request.style_samples)

    # Step 5: Review
    review = run_brand_guardian(script)

    return {
        "trends": trends,
        "insights": insights,
        "concepts": concepts,
        "script": script,
        "review": review
    }
